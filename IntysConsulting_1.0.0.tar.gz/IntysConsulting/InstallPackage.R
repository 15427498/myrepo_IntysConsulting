

path <- "~"      
install.packages(file.path(path, "IntysConsulting_1.0.0.tar.gz"), 
  lib="~", 
  repos=NULL, 
  INSTALL_opts = "--no-multiarch")


