

path <- "~"      
install.packages(file.path(path, "IntysConsulting_1.0.0.tar.gz"), 
  INSTALL_opts = "--no-multiarch")


